## Colors
red: #FC4E4E;
black: #000000;
white: #FFFFFF;
tan: #E2CBA9;
violet: #714EFC
dark-brown: #4F4444;

## fonts
font: inter
link: https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap 
size: 12px, 24px, 40px